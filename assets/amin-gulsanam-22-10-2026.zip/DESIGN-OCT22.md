# Приглашение — 22 октября 2026

Полностью новая жемчужно-голубая палитра с серебристыми деталями. Вместо прежней арочной карточки — широкая прямоугольная композиция: горизонтальные имена на большом экране, отдельный блок отсчёта, фотография рядом с адресом. На телефоне блоки выстраиваются в одну колонку. Русский текст и арабская строка восстановлены из версии v5. Имена, время 17:00 по Москве, ресторан, адрес и фото сохранены. Контрольная дата: `2026-10-22T17:00:00+03:00`.

Новые изображения созданы встроенным imagegen, сохранены в проекте:

- `dist/assets/pearl-blue-envelope.png` — голубой конверт с настоящей фактурой бумаги, тонким кружевом, жемчужной печатью и серебристо-молочной лентой.
- `dist/assets/pearl-blue-background.png` — голубая органза с белыми орхидеями, розами и гортензиями.

Промпт конверта: "Use case: product-mockup. Production website image of a closed wedding invitation envelope. Exquisitely realistic overhead photograph of an ice-blue handmade cotton paper envelope filling a 3:2 horizontal canvas. Triangular flap, narrow delicate ivory Chantilly lace along the V edge, small pearl-white wax seal embossed with crescent and botanical branch, natural silvery ivory silk ribbon. Large clear upper flap for HTML text. Fine paper fibres, blind embossed arabesque corners, authentic shadows, luminous window light. Pale ice blue, pearl white, silver-grey only. No typography, logos, watermarks or UI."

Промпт фона: "Use case: product-mockup. Photographic background for a refined wedding invitation website. Wide 3:2 overhead still life in pearl white, glacier blue and silver. Very pale icy blue matte silk organza with soft ripples. White orchids, white garden roses and very pale blue hydrangeas at far upper left and lower right; a short delicate strand of pearls. Central 70 percent quiet and nearly empty for live HTML. Bright diffused daylight, serene bridal editorial photography. No stationery, envelopes, cards, writing, logos, watermark, people or UI."

Сборка: `work/export-invitation-oct22.mjs`. Изображения встроены напрямую в HTML; итоговый файл и локальная preview-сборка побайтово совпадают. Проверены дата, русский текст, исходный файл фотографии, отсутствие старого 24 октября, отображение изображений и мобильная ширина 360 px.
